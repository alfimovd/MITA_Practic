param($installPath, $toolsPath, $package, $project)

$project.DTE.ItemOperations.Navigate('http://wpftoolkit.codeplex.com/')