﻿namespace Mita.Mvvm.ViewModels
{
    public interface IViewModel
    {

    }
}
