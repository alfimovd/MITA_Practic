﻿namespace Mita.Mvvm.Views
{
    public interface IView
    {
        object DataContext { get; set; }
    }
}
