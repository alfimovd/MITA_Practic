﻿using Mita.DataAccess;

namespace BookStore.DataAccess.Model
{
    public class BookCategory : NamedDomainObject
    {
    }
}
