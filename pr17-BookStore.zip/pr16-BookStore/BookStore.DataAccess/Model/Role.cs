﻿namespace BookStore.DataAccess.Model
{
    public enum Role
    {
        Admin = 1,
        User,
    }
}
