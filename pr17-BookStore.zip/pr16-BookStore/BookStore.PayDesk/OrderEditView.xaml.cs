﻿using System.ComponentModel.Composition;
using Mita.Mvvm.Views;

namespace BookStore.PayDesk
{
    /// <summary>
    /// Interaction logic for OrderEditView.xaml
    /// </summary>
    public partial class OrderEditView : IView
    {
        public OrderEditView()
        {
            InitializeComponent();
        }
    }
}
